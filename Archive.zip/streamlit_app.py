import streamlit as st
import openai
import re


openai.api_key_path = "api_key.txt"
def generate_quiz_from_topic(topic, num_questions=2, difficulty="medium"):
    """
    Generates multiple-choice quiz questions using OpenAI's ChatCompletion API.
    """
    prompt = f"""
    Generate {num_questions} multiple-choice quiz questions on the topic: '{topic}'.
    Difficulty: {difficulty}.
    Each question must include:
    1. A clear question statement on one line.
    2. Four answer options, each on a new line, labeled as:
       A) Option 1
       B) Option 2
       C) Option 3
       D) Option 4
    3. At the end of the block, include the correct answer in the format:
       Correct Answer: X (where X is A, B, C, or D)
    """
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are an AI assistant that generates high-quality quizzes."},
                {"role": "user", "content": prompt}
            ]
        )
        quiz_content = response['choices'][0]['message']['content'].strip()
        return quiz_content
    except Exception as e:
        st.error(f"Error calling OpenAI API: {e}")
        return None

def parse_quiz(quiz_text):
    """
    Parses the generated quiz text into structured questions and correct answers.
    """
    questions = []
    for block in quiz_text.split("Question")[1:]:
        lines = block.strip().split("\n")
        
        # Extract question text
        question_text = lines[0].strip() if len(lines) > 0 else None
        if not question_text:
            st.warning(f"Skipped malformed block (missing question): {block}")
            continue
        
        # Extract options using regex to ensure proper formatting
        options = [line.strip() for line in lines if re.match(r"^[A-D]\)", line.strip())]

        # Ensure exactly 4 options
        while len(options) < 4:
            options.append("Option not provided")
        options = options[:4]

        # Extract correct answer
        correct_answer_line = [line for line in lines if line.lower().startswith("correct answer:")]
        if not correct_answer_line:
            st.warning(f"Skipped malformed block (missing correct answer): {block}")
            continue
        correct_answer_letter = correct_answer_line[0].split(":")[-1].strip()

        # Map correct answer letter to the full option text
        correct_answer_text = next((opt for opt in options if opt.startswith(correct_answer_letter)), None)

        if not correct_answer_text:
            st.warning(f"Correct answer '{correct_answer_letter}' does not match any options in block: {block}")
            continue

        questions.append({
            "question": question_text,
            "options": options,
            "correct_answer_letter": correct_answer_letter,
            "correct_answer_text": correct_answer_text
        })
    return questions

def adjust_difficulty(score, total_questions):
    """
    Adjust difficulty based on the correct answer rate.
    """
    correct_rate = score / total_questions
    if correct_rate >= 0.8:
        return "hard"
    elif correct_rate >= 0.5:
        return "medium"
    else:
        return "easy"

def generate_feedback(questions, user_answers):
    """
    Generates specific feedback based on the quiz content and user's performance.
    """
    feedback_prompt = f"""
    Provide detailed feedback on the following quiz session. 
    Focus on the user's understanding of the knowledge content.
    Highlight their strengths, weaknesses, and areas to improve with actionable recommendations for learning.
    Provide specific suggestions (e.g., concepts to review, examples, articles, or books to study).
    
    Quiz Session:
    """
    for i, question in enumerate(questions):
        feedback_prompt += f"""
        Question {i+1}: {question['question']}
        Options: {', '.join(question['options'])}
        Correct Answer: {question['correct_answer_text']}
        User's Answer: {user_answers[i]}
        """
    
    feedback_prompt += "\nGenerate a detailed and user-specific feedback report."
    
    try:
        # Call OpenAI API for feedback generation
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a teaching assistant providing personalized feedback on quiz results."},
                {"role": "user", "content": feedback_prompt}
            ]
        )
        feedback = response['choices'][0]['message']['content'].strip()
        return feedback
    except Exception as e:
        st.error(f"Error generating feedback: {e}")
        return None

# Streamlit app
st.title("Adaptive AI Quiz Generator with Feedback")

# Initial setup for session state
if "difficulty" not in st.session_state:
    st.session_state["difficulty"] = "medium"
if "quiz_generated" not in st.session_state:
    st.session_state["quiz_generated"] = False
if "questions" not in st.session_state:
    st.session_state["questions"] = []
if "submitted" not in st.session_state:
    st.session_state["submitted"] = False
if "user_answers" not in st.session_state:
    st.session_state["user_answers"] = []

topic = st.text_input("Enter a topic for the quiz:")
num_questions = st.number_input("Number of questions:", min_value=1, max_value=10, value=2, step=1)

if st.button("Generate Quiz"):
    if topic:
        quiz_text = generate_quiz_from_topic(topic, num_questions, st.session_state["difficulty"])
        if quiz_text:
            st.session_state["questions"] = parse_quiz(quiz_text)
            st.session_state["submitted"] = False
            st.session_state["user_answers"] = []
            st.session_state["quiz_generated"] = True
        else:
            st.error("Failed to generate quiz. Please try again.")
    else:
        st.warning("Please enter a topic to generate the quiz.")

if st.session_state["quiz_generated"] and not st.session_state["submitted"]:
    st.subheader("Answer the Quiz Questions")

    if st.session_state["questions"]:
        user_answers = []
        for i, question in enumerate(st.session_state["questions"]):
            st.write(f"Question {i+1}: {question['question']}")
            options = question["options"]
            user_answer = st.radio(f"Choose an answer for Question {i+1}:", options, key=f"q{i}")
            user_answers.append(user_answer)

        if st.button("Submit Answers"):
            st.session_state["submitted"] = True
            st.session_state["user_answers"] = user_answers
    else:
        st.error("No questions available. Please generate a quiz.")

if st.session_state["submitted"]:
    st.subheader("Results")
    score = 0

    for i, question in enumerate(st.session_state["questions"]):
        st.write(f"Question {i+1}: {question['question']}")
        st.write(f"Your Answer: {st.session_state['user_answers'][i]}")
        if st.session_state["user_answers"][i] == question["correct_answer_text"]:
            st.write("✅ Correct!")
            score += 1
        else:
            st.write(f"❌ Incorrect. The correct answer was: {question['correct_answer_text']}")
        st.write("---")
    
    st.write(f"**Your Score: {score}/{len(st.session_state['questions'])}**")

    # Adjust difficulty based on score
    new_difficulty = adjust_difficulty(score, len(st.session_state["questions"]))
    st.session_state["difficulty"] = new_difficulty
    st.write(f"Next quiz difficulty: **{new_difficulty.capitalize()}**")

    # Buttons for next quiz and feedback
    col1, col2 = st.columns(2)

    with col1:
        if st.button("Generate Next Quiz"):
            quiz_text = generate_quiz_from_topic(topic, num_questions, st.session_state["difficulty"])
            if quiz_text:
                st.session_state["questions"] = parse_quiz(quiz_text)
                st.session_state["submitted"] = False
                st.session_state["user_answers"] = []
                st.session_state["quiz_generated"] = True

    with col2:
        if st.button("Feedback"):
            feedback = generate_feedback(st.session_state["questions"], st.session_state["user_answers"])
            if feedback:
                st.write("### Feedback")
                st.write(feedback)